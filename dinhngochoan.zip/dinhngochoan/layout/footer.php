<footer id="footer" class="footer-wrapper">

	

		</div>        
		</div><!-- end row -->
</div><!-- footer 1 -->


<!-- FOOTER 2 -->



<div class="absolute-footer dark medium-text-center small-text-center">
  <div class="container clearfix">

    
    <div class="footer-primary pull-left">
            <div class="copyright-footer">
              </div>
          </div><!-- .left -->
  </div><!-- .container -->
</div><!-- .absolute-footer -->
<a href="#top" class="back-to-top button invert plain is-outline hide-for-medium icon circle fixed bottom z-1" id="top-link"><i class="icon-angle-up" ></i></a>


</footer><!-- .footer-wrapper -->

</div><!-- #wrapper -->

<!-- Mobile Sidebar -->
<div id="main-menu" class="mobile-sidebar no-scrollbar mfp-hide">
    <div class="sidebar-menu no-scrollbar ">
        <ul class="nav nav-sidebar  nav-vertical nav-uppercase">
              



</li>

	
</li>



</li>

</li>

        </ul>
    </div><!-- inner -->
</div><!-- #mobile-menu -->



</script>
<script type='text/javascript' src='http://duocphutho.edu.vn/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.0.4' id='contact-form-7-js'></script>
<script type='text/javascript' src='http://duocphutho.edu.vn/wp-content/themes/flatsome/inc/extensions/flatsome-live-search/flatsome-live-search.js?ver=3.6.2' id='flatsome-live-search-js'></script>
<script type='text/javascript' src='http://duocphutho.edu.vn/wp-includes/js/hoverIntent.min.js?ver=1.8.1' id='hoverIntent-js'></script>
<script type='text/javascript' id='flatsome-js-js-extra'>
/* <![CDATA[ */
var flatsomeVars = {"ajaxurl":"http:\/\/duocphutho.edu.vn\/wp-admin\/admin-ajax.php","rtl":"","sticky_height":"70","user":{"can_edit_pages":false}};
/* ]]> */
</script>
<script type='text/javascript' src='http://duocphutho.edu.vn/wp-content/themes/flatsome/assets/js/flatsome.js?ver=3.6.2' id='flatsome-js-js'></script>
<script type='text/javascript' src='http://duocphutho.edu.vn/wp-includes/js/wp-embed.min.js?ver=5.6.12' id='wp-embed-js'></script>

</body>
</html>
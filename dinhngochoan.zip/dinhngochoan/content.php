

<a class="skip-link screen-reader-text" href="#main">Skip to content</a>

<div id="wrapper">


<header id="header" class="header header-full-width">
   <div class="header-wrapper">
	<div id="masthead" class="header-main hide-for-sticky nav-dark">
      <div class="header-inner flex-row container logo-left medium-logo-center" role="navigation">

          <!-- Logo -->
          <div  style="display: flex; justify-content: center; ">
            <!-- Header logo -->
<a href="" title="Khoa Kỹ Thuật Công Nghệ" rel="home"> 
      <img  width="150" height="150" style= " margin-right:auto" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQw7osfqgHhbuod2LaWoFJ0NjkHrqDmzASfOfQfZe_zhA&s" class="header-logo-dark" style= "margin-right: auto; " alt="Khoa Kỹ Thuật Công Nghệ"/></a> 
          </div>

          <!-- Mobile Left Elements -->
          <div class="center-col show-for-medium flex-center">
            <ul class="mobile-nav nav nav-center">
              <li class="nav-icon has-icon">
  		<a href="#" data-open="#main-menu" data-pos="left" data-bg="main-menu-overlay" data-color="" class="is-small" aria-controls="main-menu" aria-expanded="false">
		
		  <i class="icon-menu" ></i>
		  		</a>
	</li>            </ul>
          </div>

          <!-- Left Elements -->
          <!-- <div class="flex-col hide-for-medium flex-left
            flex-grow">
            <ul class="header-nav header-nav-main nav nav-left  nav-uppercase" >
                          </ul>
          </div> -->

          <!-- Right Elements -->
          <!-- <div class="flex-col hide-for-medium flex-right">
            <ul class="header-nav header-nav-main nav nav-right  nav-uppercase">
                          </ul>
          </div> -->

          <!-- Mobile Right Elements -->
          <!-- <div class="flex-col show-for-medium flex-right">
            <ul class="mobile-nav nav nav-right ">
                          </ul>
          </div> -->

      </div>
     
            <!-- Header divider -->
      <div class="container"><div class="top-divider full-width"></div></div>
      </div><!-- .header-main --><div id="wide-nav" class="header-bottom wide-nav hide-for-sticky hide-for-medium">
    <div class="flex-row container">

                        <div class="flex-col hide-for-medium flex-left">
                <ul class="nav header-nav header-bottom-nav nav-left ">
				<li id="menu-item-372" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-372"><a href=>Email:khoakythuatcongnghe.hvu.edu.vn</a></li>


</li>
<li id="menu-item-373" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-373"><a href="https://www.facebook.com/ktcn.hvu.edu.vn?locale=vi_VN">Facebook</a></li>

</ul>
</li>


</li>
<li id="menu-item-2593" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children  menu-item-2593 has-dropdown"><a href="" class="nav-top-link">Tổ quản trị web: hoanhuynj3@gmail.com<i class="icon-angle-down" ></i></a>

</ul>
</li>


</li>
                </ul>
            </div><!-- flex-col -->
            
            
                        <div class="flex-col hide-for-medium flex-right flex-grow">
              <ul class="nav header-nav header-bottom-nav nav-right ">
                   <li class="header-search-form search-form html relative has-icon">
	<div class="header-search-form-wrapper">
		<div class="searchform-wrapper ux-search-box relative form-flat is-normal"><form method="get" class="searchform" action="" role="search">
		<div class="flex-row relative">
			<div class="flex-col flex-grow">
	   	   <input type="search" class="search-field mb-0" name="s" value="" id="s" placeholder="Tìm kiếm" />
			</div><!-- .flex-col -->
			<div class="flex-col">
				<button type="submit" class="ux-search-submit submit-button secondary button icon mb-0">
					<i class="icon-search" ></i>				</button>
			</div><!-- .flex-col -->
		</div><!-- .flex-row -->
    <div class="live-search-results text-left z-top"></div>
</form>
</div>	</div>
</li>              </ul>
            </div><!-- flex-col -->
            
            
    </div><!-- .flex-row -->
</div><!-- .header-bottom -->

<div class="header-bg-container fill"><div class="header-bg-image fill"></div><div class="header-bg-color fill"></div></div><!-- .header-bg-container -->   </div><!-- header-wrapper-->
</header>

<marquee direction="left" behavior="scroll" scrolldelay="5" scrollamount="5" onmouseover="this.stop();" onmouseout="this.start();"  style ="color:blue"><span class="cau-chao">Trang thông tin điện tử Khoa Kỹ Thuật Công Nghệ</span></marquee>

<main id="main" class="">

<div class="page-wrapper page-right-sidebar">
<div class="row">
<div class="large-3 col">
	<div id="secondary" class="widget-area " role="complementary">
		<aside id="nav_menu-2" class="widget widget_nav_menu"><div class="menu-menu-tin-tuc-su-kien-container"><ul id="menu-menu-tin-tuc-su-kien" class="menu"><li id="menu-item-371" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-371"><a >Địa chỉ: Tầng 1 nhà hành chính hiệu bộ</a></li>

<li id="menu-item-3271" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-3271"><a href="">Trưởng khoa:TS.nguyễn hùng cường </a>

</li>
<li id="menu-item-3274" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-3274"><a href="">Tổ quản trị wed: hoahuynhj3@gmail.com</a>

</li>

</li>

</li>



</div>
		</aside><aside id="text-3" class="widget widget_text"><span class="widget-title "><a href= "https://www.youtube.com/watch?v=_a0ohjPJzLg&t=1s">youtube</a></span><div class="is-divider small"></div>			<div class="textwidget"><div id="fb-root"></div>
<p><script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v2.6&appId=1058228637573834";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script></p>
<div class="fb-page" data-href="" data-data-hide-cover="false" data-show-facepile="true"></div>
</div>
		</aside><aside id="text-5" class="widget widget_text">			<div class="textwidget"><p></p>
</div>
		
		</aside><aside id="text-6" class="widget widget_text"><span class="widget-title "><span>SĐT: 0976945061</span></span><div class="is-divider small"></div>			

<p>&nbsp;</p>

		</aside></div><!-- #secondary -->
</div><!-- .sidebar -->
<div id="content" class="large-9 left col col-divided small-col-first" role="main">
	<div class="page-inner">
				
				<section class="section section-tin section-tin-moi" id="section_88697032">
		<div class="bg section-bg fill bg-fill  bg-loaded" >

			
			
			

		</div><!-- .section-bg -->

		<div class="section-content relative">
			
<div class="row row-small"  id="row-922517473">
<div class="col medium-8 small-12 large-8"  ><div class="col-inner"  >

  
    <div class="row large-columns-1 medium-columns-1 small-columns-1 slider row-slider slider-nav-reveal"  data-flickity-options='{"imagesLoaded": true, "groupCells": "100%", "dragThreshold" : 5, "cellAlign": "left","wrapAround": true,"prevNextButtons": true,"percentPosition": true,"pageDots": true, "rightToLeft": false, "autoPlay" : 4000}'>

  		<div class="col post-item" >
			<div class="col-inner">
			
				<div class="box box-shade dark box-text-bottom box-blog-post has-hover">

            					<div class="box-image" >
  						<div class="image-cover" style="padding-top:56.25%;">
						
  							
          					<div  >
								
					<div class="box-text-inner blog-post-inner">
                          
					
										<h4 style=" color:black ">Giới thiệu khoa</h4>

				
										<P style="color:black">Khoa Kỹ thuật – Công nghệ được thành lập 3/2016 theo Quyết định số 258/QĐ- ĐHHV ngày 02/03/2016 của Hiệu trưởng Trường Đại học Hùng Vương. Khoa có  21 cán bộ giảng viên , trong đó có 12 nam và 9 nữ .Khoa có chức năng đào tạo, nhiệm vụ là đào tạo đội ngũ cán bộ nhóm ngành Kỹ thuật – Công nghệ có trình độ cao, tay nghề giỏi phục vụ phát triển Kỹ thuật – công nghệ cho tỉnh Phú Thọ và cả nước. Hiện nay, Khoa được Nhà trường giao quản lý và thực hiện 3 ngành đào tạo: Đại  học Công nghệ thông tin; Đại học Công nghệ kỹ thuật điện, điện tử; Đại học Công nghệ kỹ thuật cơ khí. Khoa có thuận lợi là các ngành đào tạo đều trong xu thể phát triển của đất nước, có nhu cầu về nguồn nhân lực rất lớn…
Do đó, sinh viên cơ bản có việc làm ngay sau khi ra trường. Các ngành nghề đào tạo của khoa đều được xây dựng theo định hướng ứng dụng giúp sinh viên dễ dàng thích nghi với môi trường làm việc thực tiễn khi ra trường.
</p>                                   <p style="color:black"> phương thức tuyển sinh nhanh chóng đơn giản</p>
                                   <p style="color:black"> sử dụng kết quả kỳ thi thi Tốt nghiệp THPT năm 2023</p>
								   <p style="color:black"> Xét tuyển dựa vào kết quả học tập lớp 12 bậc THPT </p>
								   <p style="color:black">  Xét tuyển thẳng và ưu tiên xét tuyển</p>
					                    
					
					
					</div><!-- .box-text-inner -->
					</div><!-- .box-text -->
									</div><!-- .box -->
				</a><!-- .link -->
			</div><!-- .col-inner -->
		</div><!-- .col -->
		<div class="col post-item" >
			<div class="col-inner">
			<a href="" class="plain">
				<div class="box box-shade dark box-text-bottom box-blog-post has-hover">
            					<div class="box-image" >
  						
  							
  						  					</div><!-- .box-image -->
          					<div class="box-text text-left is-small" >
					<div class="box-text-inner blog-post-inner">

					
										
					                    
					
					
					</div><!-- .box-text-inner -->
					</div><!-- .box-text -->
									</div><!-- .box -->
				</a><!-- .link -->
			</div><!-- .col-inner -->
		</div><!-- .col -->
		
					
					
					</div><!-- .box-text-inner -->
					</div><!-- .box-text -->
									</div><!-- .box -->
				</a><!-- .link -->
			</div><!-- .col-inner -->
		</div><!-- .col -->
		
		
		
		<div class="col post-item" >
			<div class="col-inner">
			<a href="https://www.facebook.com/ktcn.hvu.edu.vn/posts/pfbid02PtiaCCd8EsYocvuj68GAjbtTmoA8Rs5dJSD3d8AdpdDiRrV66DzYSWUrapDSJmeSl" class="plain">
				<div class="box box-vertical box-text-bottom box-blog-post has-hover">
            					<div class="box-image" style="width:30%;">
  						<div class="image-cover" style="padding-top:56.25%;">
  							<img width="699" height="695" src="https://scontent-fra3-1.xx.fbcdn.net/v/t39.30808-6/352208498_235779355839288_1213055608344915985_n.jpg?stp=dst-jpg_s851x315&_nc_cat=103&ccb=1-7&_nc_sid=3635dc&_nc_ohc=HQwIK4ceNqgAX8u0kee&_nc_ht=scontent-fra3-1.xx&oh=00_AfCAMbHsqxEveZyID4A4ybpGnK-EHvqn9AhbEsHOfSVyGQ&oe=65799646" class="attachment-medium size-medium wp-post-image" alt="" loading="lazy" />  							  							  						</div>
  						  					</div><!-- .box-image -->
          					<div class="box-text text-left is-xsmall" >
					<div class="box-text-inner blog-post-inner">

					
										<h5 class="post-title is-large "> Hãy đến với Khoa Kỹ thuật - Công nghệ, Trường Đại học Hùng Vương🥰🥰🥰
</h5>
									
										<div class="is-divider"></div>
					                    
					
					
					</div><!-- .box-text-inner -->
					</div><!-- .box-text -->
									</div><!-- .box -->
				</a><!-- .link -->
			</div><!-- .col-inner -->
		</div><!-- .col -->
		
<style scope="scope">

</style>
</div>
		</div><!-- .section-content -->

		
<style scope="scope">

#section_88697032 {
  padding-top: 30px;
  padding-bottom: 30px;
}
</style>
	</section>
	
	<section class="section section-tin section-loai-tin" id="section_236055755">
		<div class="bg section-bg fill bg-fill  bg-loaded" >

			
			
			

		</div><!-- .section-bg -->

		
					</div>
						</a>		
<style scope="scope">

#image_1161006298 {
  width: 100%;
}
</style>
	</div>
	
</div></div>
<div class="col small-12 large-12"  ><div class="col-inner"  >
<div class="container section-title-container" ><h3 class="section-title section-title-normal"><b></b><span class="section-title-main" style="font-size:88%;">một số hoạt động gần đây </span><b></b></h3></div><!-- .section-title -->

  
    <div class="row large-columns-4 medium-columns-1 small-columns-1 row-small">
  		<div class="col post-item" >
			<div class="col-inner">
			<a href="https://www.facebook.com/ktcn.hvu.edu.vn/posts/pfbid04EtjLBMWH7z6ujXsaK6E3q8pKUQKvKp8uKzCXpFFYafUbm6VgfjZWynVBdAXEVdGl" class="plain">
				<div class="box box-normal box-text-bottom box-blog-post has-hover">
            					<div class="box-image" style="border-radius:8%;">
  						<div class="image-cover" style="padding-top:56.25%;">
  							<img width="700" height="466" src="https://scontent-hel3-1.xx.fbcdn.net/v/t39.30808-6/399531056_818700450259883_4776460696443164971_n.jpg?_nc_cat=105&ccb=1-7&_nc_sid=3635dc&_nc_ohc=oI5-H4xUE6kAX9pzBim&_nc_ht=scontent-hel3-1.xx&oh=00_AfCuX3IpwZQfjLkKA7bcD74NwMN5bRf_aA5gbsBpSFrKWw&oe=657B156A" class="attachment-medium size-medium wp-post-image" alt="" loading="lazy" />  							  							  						</div>
  						  					</div><!-- .box-image -->
          					<div class="box-text text-center is-small" >
					<div class="box-text-inner blog-post-inner">

					
										<h5 class="post-title is-large "> Cuộc thi hùng vương code challenge</h5>
										<div class="is-divider"></div>
										<p class="from_the_blog_excerpt "> Các thí sinh đã lần lượt trải qua các vòng thi Viblo Code, Viblo CFT và lập trình thi đấu đối kháng Bot với vòng thi Viblo Battle.
💐 Sau 03 vòng thi vô cùng gay cấn và kịch tính, các thí sinh xuất sắc giành được giải thưởng bao gồm:
💥Giải nhất: Team Cừu vui vẻ và sói xám
💥Giải nhì: Team Một cắk
💥Giải ba: Team K20CNTTB					</p>
					                    
					
					
					</div><!-- .box-text-inner -->
					</div><!-- .box-text -->
									</div><!-- .box -->
				</a><!-- .link -->
			</div><!-- .col-inner -->
		</div><!-- .col -->
		<div class="col post-item" >
			<div class="col-inner">
			<a href="https://www.facebook.com/ktcn.hvu.edu.vn/posts/pfbid021DPdhGbWxM4P8kS26TBNsac5nhYZWRua5ptnbzps7qmdy5TyFLs29kKyMKN5b154l" class="plain">
				<div class="box box-normal box-text-bottom box-blog-post has-hover">
            					<div class="box-image" style="border-radius:8%;">
  						<div class="image-cover" style="padding-top:56.25%;">
  							<img width="700" height="466" src="https://scontent-hel3-1.xx.fbcdn.net/v/t39.30808-6/399878262_816744587122136_5668126103526130096_n.jpg?stp=cp6_dst-jpg_s600x600&_nc_cat=100&ccb=1-7&_nc_sid=dd5e9f&_nc_ohc=_TR-QNxN6N8AX-3NOOt&_nc_ht=scontent-hel3-1.xx&oh=00_AfBPCNuBcj8Kms3GZP7gW8uquZsVHkqh96vZoOrsJA861g&oe=657B2F44" class="attachment-medium size-medium wp-post-image" alt="" loading="lazy" />  							  							  						</div>
  						  					</div><!-- .box-image -->
          					<div class="box-text text-center is-small" >
					<div class="box-text-inner blog-post-inner">

					
										<h5 class="post-title is-large ">Lễ tri ân các thầy cô 20/11 và Cuộc thi hùng biện cấp khoa</h5>
										<div class="is-divider"></div>
										<p class="from_the_blog_excerpt "> Liên chi Đoàn Khoa Kỹ thuật - công nghệ tưng bừng tổ chức lễ tri ân thầy cô nhân ngày 20/11 và Cuộc thi Hùng biện cấp Khoa 🥰🥰🥰
⚡️⚡️⚡️Cuộc thi bao gồm các thí sinh đến từ các  lớp của Khoa KTCN tham gia với tinh thần quyết tâm và nghiêm túc,  các thí sinh đã hoàn thành phần thi của mình một cách xuất sắc ⭐️⭐️⭐️
🏵Cuộc thi đã tìm ra chủ nhân của các giải thưởng, bao gồm: 
🥇Giải nhất: Palongvue Thongphan- lớp K19 CNTT A
🥈 Giải nhì: Nguyễn Văn Nhiên - lớp K20 Điện - Điện tử				</p>
					                    
					
					
					</div><!-- .box-text-inner -->
					</div><!-- .box-text -->
									</div><!-- .box -->
				</a><!-- .link -->
			</div><!-- .col-inner -->
		</div><!-- .col -->
		<div class="col post-item" >
			<div class="col-inner">
			<a href="https://www.facebook.com/ktcn.hvu.edu.vn/posts/pfbid0V8sLmrTdBNiQ9kxR6DNjsqddKqZCEuqJmb3Ybd81a4F37GgDQjWho7RBjw7WxEZgl" class="plain">
				<div class="box box-normal box-text-bottom box-blog-post has-hover">
            					<div class="box-image" style="border-radius:8%;">
  						<div class="image-cover" style="padding-top:56.25%;">
  							<img width="700" height="466" src="https://scontent-hel3-1.xx.fbcdn.net/v/t39.30808-6/398026989_814962363967025_4116603692996045301_n.jpg?stp=dst-jpg_s960x960&_nc_cat=111&ccb=1-7&_nc_sid=3635dc&_nc_ohc=Z_DVioEDmOUAX-geQWt&_nc_ht=scontent-hel3-1.xx&oh=00_AfBPf04zgJQ5baHHeFEoYOfNgA8f5fyGIwSy8LXD5R_TPg&oe=657ADE69" class="attachment-medium size-medium wp-post-image" alt="" loading="lazy" />  							  							  						</div>
  						  					</div><!-- .box-image -->
          					<div class="box-text text-center is-small" >
					<div class="box-text-inner blog-post-inner">

					
										<h5 class="post-title is-large "> Cuộc thi ý tưởng khởi nghiệp sáng tạo công nghệ quốc gia </h5>
										<div class="is-divider"></div>
										<p class="from_the_blog_excerpt "> Ý tưởng Khởi nghiệp sáng tạo Công nghệ Quốc gia năm 2023″ với mục tiêu thúc đẩy sự sáng tạo khoa học công nghệ của đội ngũ tri thức trẻ gắn với thị trường, cùng với đó cuộc thi tạo không gian giao lưu, sáng tạo: chia sẻ các xu hướng khoa học công nghệ trên thế giới;
										01 Dự án khởi nghiệp của Sinh viên Đại Học Hùng Vương
❤️❤️❤️Dự án "QUẠT NĂNG LƯỢNG MẶT TRỜI" của nhóm sinh viên Vũ Đức Thắng, Nguyễn Trọng Minh, Nguyễn Đức Dũng ở lĩnh vực 
Công nghệ vật liệu, công nghiệp, tự động hóa đã được lọt vào top 30 đội xuất sắc nhất và đi tiếp vào vòng 2 của cuộc thi ❤️❤️				</p>
					                    
					
					
					</div><!-- .box-text-inner -->
					</div><!-- .box-text -->
									</div><!-- .box -->
				</a><!-- .link -->
			</div><!-- .col-inner -->
		</div><!-- .col -->
		<div class="col post-item" >
			<div class="col-inner">
			<a href="https://m.facebook.com/story.php?story_fbid=pfbid05dbhDx6xLwouvmD8a66si7XbByJzWJCMHwSoeC6wHpAkMTWEWweRFcF4a7DvQDXvl&id=100063598057535&mibextid=Nif5oz" class="plain">
				<div class="box box-normal box-text-bottom box-blog-post has-hover">
            					<div class="box-image" style="border-radius:8%;">
  						<div class="image-cover" style="padding-top:56.25%;">
  							<img width="700" height="466" src="https://scontent-hel3-1.xx.fbcdn.net/v/t39.30808-6/395793039_809496091180319_1520613846719192870_n.jpg?_nc_cat=104&ccb=1-7&_nc_sid=3635dc&_nc_ohc=n2snGUz4mWQAX8u-Tym&_nc_ht=scontent-hel3-1.xx&oh=00_AfBfDQwL9sSvMRsmhpilt3E5i2NIEjsikuwypa5cw_ojxw&oe=657C4BE1" class="attachment-medium size-medium wp-post-image" alt="" loading="lazy" />  							  							  						</div>
  						  					</div><!-- .box-image -->
          					<div class="box-text text-center is-small" >
					<div class="box-text-inner blog-post-inner">

					
										<h5 class="post-title is-large ">SINH VIÊN NGÀNH CÔNG NGHỆ KỸ THUẬT ĐIỆN - ĐIỆN TỬ THAM QUAN VÀ TRẢI NGHIỆM THỰC TẾ TẠI DOANH NGHIỆP FDI</h5>
										<div class="is-divider"></div>
										<p class="from_the_blog_excerpt "> Nhằm nâng cao chất lượng đào tạo Khoa Kỹ thuật - Công nghệ tổ chức cho sinh viên K20 và K21 đi thăm quan thực tế tại 02 Doanh nhiệp: Công ty TNHH VIETNAM SUNERGY CELL và công ty TNHH INST MAGNETIC NEW MATERIALS VIET NAM ở khu công nghiệp Cẩm Khê, Huyện Cẩm Khê, Tỉnh Phú thọ. 
Sinh viên có điều kiện:
🍎 Tìm hiểu thực tế dây chuyền sản xuất tại doanh nghiệp nước ngoài.
🍎🍎 Sinh viên được tham quan các dây truyền sản xuất tự động hóa về sản xuất pin năng lượng mặt trời và dây truyền sản xuất nam châm 				</p>
					                    
					
					
					</div><!-- .box-text-inner -->
					</div><!-- .box-text -->
									</div><!-- .box -->
				</a><!-- .link -->
			</div><!-- .col-inner -->
		</div><!-- .col -->
</div>
</div></div>



		
<style scope="scope">

#section_236055755 {
  padding-top: 30px;
  padding-bottom: 30px;
}
</style>
	</section>
	
	<section class="section section-tin" id="section_1165294356">
		<div class="bg section-bg fill bg-fill  bg-loaded" >

			
			
			

		</div><!-- .section-bg -->

		<div class="section-content relative">
			
		</div><!-- .section-content -->

		
<style scope="scope">

#section_1165294356 {
  padding-top: 30px;
  padding-bottom: 30px;
}
</style>
	</section>
	
	<section class="section section-tin section-tin-doi" id="section_1156084673">
		<div class="bg section-bg fill bg-fill  bg-loaded" >

			
			
			

		</div><!-- .section-bg -->

		<div class="section-content relative">
			


		
<style scope="scope">

#section_1156084673 {
  padding-top: 30px;
  padding-bottom: 30px;
}
</style>
	</section>
	
			
			
			</div><!-- .page-inner -->
</div><!-- .#content large-9 left -->


	
</div><!-- .row -->
</div><!-- .page-right-sidebar container -->



</main><!-- #main -->

<footer id="footer" class="footer-wrapper">

	


<!-- FOOTER 2 -->



<div class="absolute-footer dark medium-text-center small-text-center">
  <div class="container clearfix">

    
    <div class="footer-primary pull-left">
            <div class="copyright-footer">
              </div>
          </div><!-- .left -->
  </div><!-- .container -->
</div><!-- .absolute-footer -->
<a href="#top" class="back-to-top button invert plain is-outline hide-for-medium icon circle fixed bottom z-1" id="top-link"><i class="icon-angle-up" ></i></a>


